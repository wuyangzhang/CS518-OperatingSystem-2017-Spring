#ifndef _BASIC_THREAD_TESTS_H_
#define _BASIC_THREAD_TESTS_H_
void basicThreadTests();
void grandFinale();
void preemptiveTests();
void lockTests();
void condTests();
#endif 
